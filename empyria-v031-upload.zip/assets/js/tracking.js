/* Spelersregistratie.
   Vul hieronder je Supabase Project URL in. Laat je hem leeg, dan doet
   dit bestand niets en draait het spel gewoon door. */
(function () {
  var SUPABASE_URL = '';               // bv. 'https://abcdefgh.supabase.co'
  var BUILD        = 'v0.31';

  if (!SUPABASE_URL) return;
  var tg = window.Telegram && window.Telegram.WebApp;
  if (!tg || !tg.initData) return;     // buiten Telegram: niets registreren

  var endpoint = SUPABASE_URL.replace(/\/+$/, '') + '/functions/v1/track';
  var busy = false;

  function ping() {
    if (busy) return;
    busy = true;
    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initData: tg.initData, build: BUILD })
    })
      .catch(function () {})            /* stil falen, nooit het spel breken */
      .then(function () { busy = false; }, function () { busy = false; });
  }

  ping();
  setInterval(ping, 5 * 60 * 1000);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) ping();
  });
})();
