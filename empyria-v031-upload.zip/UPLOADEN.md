# Empyria v0.31 uploaden

Upload de volledige inhoud van deze map, inclusief assets/ en alle submappen. Behoud de structuur. Open index.html via je hosting of een lokale webserver. Gebruik voor Telegram de link naar index.html?v=031.

assets/audio: muziek
assets/images: app-iconen en deelafbeelding (webversie)
assets/vendor: Three.js
assets/js/industrial-pack.js: procedureel industrieel asset pack
assets/js/game.js: game, 3D-modellen, overige texturegenerators en interface-iconen

Gebouwen en terreinteksten worden in code gegenereerd; er zijn geen losse GLB-modellen of gekochte texturebestanden. De game blijft deze assets lokaal genereren.

assets/js/tracking.js: spelersregistratie via Telegram (optioneel)

## Spelersregistratie aanzetten

1. Open assets/js/tracking.js en vul SUPABASE_URL in met je Project URL.
   Laat je hem leeg, dan gebeurt er niets en draait het spel gewoon door.
2. In Supabase moeten de migratie 0009_players.sql en de Edge Function
   `track` uitgerold zijn, en het bot-token als secret staan:

       supabase db push
       supabase secrets set TELEGRAM_BOT_TOKEN=123456:AA...
       supabase functions deploy track --no-verify-jwt

3. Kijken wie er speelt, in de SQL Editor:

       select * from stats_overview;
       select * from stats_per_dag;

De registratie werkt alleen binnen Telegram en slaat alleen id, voornaam,
gebruikersnaam, taal en tijdstippen op. Dat zijn persoonsgegevens: zorg
voor een privacyverklaring met doel en bewaartermijn.
